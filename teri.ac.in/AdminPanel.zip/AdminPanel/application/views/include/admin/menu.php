			<div class="page-sidebar sidebar horizontal-bar">
                <div class="page-sidebar-inner">
                    <ul class="menu accordion-menu">
                        <li class="nav-heading"><span>Navigation</span></li>
                       <li class="droplink">
                        	<a href="#">
                        		<span class="fa fa-globe"></span>
                        		<p>&nbsp;&nbsp;&nbsp;News</p>
                        		<span class="arrow"></span>
                        	</a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo base_url();?>apanel/enquiryList">Enquiry</a></li>
                                <li><a href="<?php echo base_url();?>apanel/latestNews">Headline</a></li>
                                <li><a href="<?php echo base_url();?>apanel/noticeBoard">Notice</a></li>
                                <li><a href="<?php echo base_url();?>apanel/tourProgram">TOUR PROGRAM</a></li>
                            </ul>
                        </li>
                        
                       <li class="droplink">
                        	<a href="#">
                        		<span class="menu-icon icon-credit-card"></span>
                        		<p>&nbsp;&nbsp;&nbsp;Gallery</p>
                        		<span class="arrow"></span>
                        	</a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo base_url();?>apanel/gallery">Photo Gallery</a></li>
                                 <li><a href="#">Vedio Gallery</a></li>
                               
                            </ul>
                        </li>
                         <li class="droplink">
                        	<a href="#">
                        		<span class="fa fa-briefcase"></span>
                        		<p>&nbsp;&nbsp;&nbsp;Product</p>
                        		<span class="arrow"></span>
                        	</a>
                            <ul class="sub-menu">
                                <li><a href="<?php echo base_url();?>apanel/product">Add Product</a></li>
                               
                            </ul>
                        </li>
                       
                      
                       <li class="droplink">
                        	<a href="#">
                        		<span class="menu-icon icon-settings"></span>
                        		<p>Settings</p>
                        		<span class="arrow"></span>
                        	</a>
                            <ul class="sub-menu">
	                           <li>
		                        	<a href="#">
		                        		<span class="glyphicon glyphicon-list-alt">
		                        		</span><p>&nbsp;&nbsp;&nbsp;ADD DISEASES</p>
		                        	</a>
	                       		</li>
	                       		
	                       		
                            </ul>
                        </li>
                       
                       
                    </ul>
                </div><!-- Page Sidebar Inner -->
            </div><!-- Page Sidebar -->
            
            <div class="page-inner">
                <div class="page-breadcrumb">
                    <ol class="breadcrumb container">
                        <li class="active"><?php echo $smallTitle; ?></li>
                    </ol>
                </div>
                <div class="page-title">
                    <div class="container">
                        <h3><?php echo $bigTitle; ?></h3>
                    </div>
                </div>			
			
			
	